from N3.Funcoes import *

#Chamamos as funcoes cabeçalho e login. Se colocarem o login e senha correstos, chama a funcao menu_opcao pra iniciar o programa.
cabecalho()
print()
usuario = str(input('Login: '))
senha = str(input('Senha: '))
if login(usuario, senha):
    menu_opcao()



