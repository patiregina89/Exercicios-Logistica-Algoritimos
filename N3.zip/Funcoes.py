def cabecalho():
    print(('*' * 50))
    print('*'*16, 'FACULDADE CESUSC', '*'*16)
    print('CURSO: ANÁLISE E DESENV. DE SISTEMAS')
    print('Discipl.: Lógica Computacional e Algorítimos')
    print('Prof.: Roberto fabiano Fernandes')
    print('Turma: ADS11')
    print('Equipe:Leonardo Portes e Patricia Regina Rodrigues')
    print('Avaliação N3')
    print(('*'*50))

#--------------------------------------------------------------------------------

def login(usuario, senha):
    if usuario != 'ads' and senha != 'python':#determinamos o login e senha. Se não for preenchido corretamente dará a msg de erro, caso contrário o arquivo principal chama a função menu_opçoes
        print('\033[31mLogin Inválido!!\033[m')
        return False
    else:
        return True

#--------------------------------------------------------------------------------

def menu(): #essa função mostra as opções de menu e retorna a escolha do usuário
    menu_str = '''\n\033[1mSISTEMA DE CADASTRO PARA PACIENTES COM COVID – 19\033[0m'

          \033[1;4m___MENU___\033[0m
          1 - Cadastrar Pacientes
          2 - Listar Pacientes
          3 - Alterar Dados do Pacientes
          4 - Excluir Dados do Pacientes
          5 - Realizar Backup do arquivo
          0 - Sair
          Digite a opção desejada: '''
    return input(menu_str)

#--------------------------------------------------------------------------------

def menu_opcao(): #aqui determinamos qual função a opção escolhida pelo usuário será rodada.
    while True:
        opcao = menu()
        if opcao == '1':
            cadastrar()
        elif opcao == '2':
            listar()
        elif opcao == '3':
            nome = input('Insira o nome que deseja alterar: ')
            alterar_dados(nome)
        elif opcao == '4':
            nome = input('Insira o nome que deseja excluir: ')
            excluir_dados(nome)
        elif opcao == '5':
            backup()
        else:
            print('Programa finalizado!')
            break

#--------------------------------------------------------------------------------

def cadastrar(): #função de cadastro de novos pacientes
    try:
        arquivo = open('dados.txt', 'a')

        nome = input('Nome do paciente: ').title() #utilizamos .title para ficar todos com a mesma formatação independente como o usuário escreva.
        cns = input('CNS: ')
        bairro = input('Bairro: ').title()
        us = input('Unidade de Saúde: ').title()
        nasc = input('Data de nascimento: ')
        print("Informe as comorbidades, corforme opções abaixo:")
        print("     Diabetes")
        print("     Doenças Respiratórias")
        print("     Doenças Cardiovasculares")
        print("     Hipertensão")
        print("     Nenhuma Comorbidade")
        comorbidades= str(input('Comorbidade: ')).title()
        inicio_sin = input('Data de início dos sintomas: ')
        ende = input('Endereço completo: ').title()
        tel1 = input('Telefone 1: ')
        tel2 = input('Telefone 2: ')
        while tel1 == '':#determinamos que é obrigatório o preenchiemnto de pelo menos 1 telefone, caso nao preencha nada, entrará em looping até ser preenchido.
            print('\033[0;31mObrigatório preencher um telefone no cadastro!!!\033[m')
            tel1 = input('Telefone 1: ')
        print("Informe os sintomos iniciais, corforme opções abaixo: ")
        print("     Febre")
        print("     Dor de Garganta")
        print("     Tosse")
        print("     Coriza")
        print("     Dificuldade Respiratória")
        print("     Paciente sem Sintomas")
        sintomas = str(input('Sintomas Inícias: ')).title()

        arquivo.write(nome + ';' + cns + ';' + bairro + ';' + us + ';' + nasc + ';' + comorbidades + ';' +
                      inicio_sin + ';' + ende + ';' + tel1 + ';' + tel2 + ';' + sintomas + ';' + '\n') #os dados cadastrados serão salvos no arquivo com um ; dividindo-os para determinar cada item
                                                                    # da lista. E ao final do cadastro do paciente, quebra linha para que as informações de cada paciente fique em uma linha.

        arquivo.close()
        print('\033[34mCadastro realizado com sucesso!!\033[0m')
    except IOError as error:
        print('Erro', error)

#--------------------------------------------------------------------------------

def listar(): #função para listar todos os pacientes cadastrados
    try:
        arquivo = open('dados.txt', 'r+').readlines()
        print('\n\033[1mLISTA DE PACIENTES CADASTRADOS: \033[m')
        for linha in arquivo:
            posicao_linha = linha.split(';')#o programa irá abrir e verifcar em cada linha do arquivo os itens (separados por ;) e irá imprimir a posição_linha no item 0 de cada linha,
                                            # ou seja, o nome.
            print(posicao_linha[0])
        print('---------END---------')
    except IOError as error:
        print('Erro', error)

#--------------------------------------------------------------------------------

def alterar_dados(nome): #função para alterar dados
    novo_nome = nome.title()
    pos_linha = -1 #determinamos que pos_linha é igual a -1, pois não existe a posição -1, então não irá afetar qualquer valor informado no exercício.
    try:#o prgrama então abrirá o arquivo .txt e irá ler todas as linhas em busca do nome informado para alterar.
        with open('dados.txt', 'r') as arquivo:
            linhas = arquivo.readlines()
            for linha in linhas:
                if linha.startswith(novo_nome):
                    pos_linha = linhas.index(linha)

        if pos_linha == -1: #se não achar, mostra essa mensagem
            print('\033[31mCadastro não encontrado!\033[0m')
            return 0

        linhas.pop(pos_linha)#se achar ele irá solicitar os novos dados..
        nome = input('Insira o novo nome: ').title()
        cns = input('Insira o novo CNS: ')
        bairro = input('Insira o novo Bairro: ')
        us = input('Insira a nova Unidade de Saúde: ').title()
        nasc = input('Insira a nova Data de nascimento: ')
        print("Informe as comorbidades, corforme opções abaixo:")
        print("     Diabetes")
        print("     Doenças Respiratórias")
        print("     Doenças Cardiovasculares")
        print("     Hipertensão")
        print("     Nenhuma Comorbidade")
        comorbidades = str(input('Comorbidade: ')).title()
        inicio_sin = input('Insira a nova Data de início dos sintomas: ')
        ende = input('Insira o novo Endereço completo: ').title()
        tel1 = input('Insira o novo Telefone 1: ')
        tel2 = input('Insira o novo Telefone 2: ')
        while tel1 == '':
            print('\033[0;31mObrigatório preencher um telefone no cadastro!!!\033[m')
            tel1 = input('Telefone 1: ')
        print("Informe os sintomos iniciais, corforme opções abaixo: ")
        print("     Febre")
        print("     Dor de Garganta")
        print("     Tosse")
        print("     Coriza")
        print("     Dificuldade Respiratória")
        print("     Paciente sem Sintomas")
        sintomas = str(input('Sintomas Inícias: ')).title()

        item = (nome + ';' + cns + ';' + bairro + ';' + us + ';' + nasc + ';' + comorbidades + ';' +
                inicio_sin + ';' + ende + ';' + tel1 + ';' + tel2 + ';' + sintomas + ';' + '\n')
        linhas.insert(pos_linha, item)
        arquivo = open('dados.txt', 'w')#então irá abrir o arquivo.txt e reescrever na linha encontrada as novas informações.
        arquivo.writelines(linhas)
        arquivo.close()
        print('\033[34mCadastro alterado com sucesso!!\033[0m')
    except IOError as error:
        print('Erro', error)

#--------------------------------------------------------------------------------

def excluir_dados(nome): #exclui todos os dados daquele paciente, mas não o arquivo
    excluir_nome = nome.title()
    pos_linha = -1
    try:#o prgrama então abrirá o arquivo .txt e irá ler todas as linhas em busca do nome informado para excluir.
        with open('dados.txt', 'r') as arquivo:
            linhas = arquivo.readlines()
            for linha in linhas:
                if linha.startswith(excluir_nome):
                    pos_linha = linhas.index(linha)

        if pos_linha == -1:#se não achar, mostra essa mensagem
            print('\033[31mCadastro não encontrado!\033[0m')
            return 0

        linhas.pop(pos_linha) #se achar ele irá excluir todos os dados preenchidos daquele paciente selecionado
        arquivo = open('dados.txt', 'w')
        arquivo.writelines(linhas)
        arquivo.close()
        print('\033[34mCadastro removido com sucesso!!\033[0m')
        return 0
    except IOError as error:
        print('Erro', error)

#--------------------------------------------------------------------------------

def backup(): #irá realizar o backup do arquivo Dados.txt para um outro arquivo chamado backup_Dados.txt
    try:
        arquivo1 = open('dados.txt', 'r')
        arquivo2 = open('backup_dados.txt', 'w')
        for texto in arquivo1:
            arquivo2.write(texto)
        arquivo1.close()
        arquivo2.close()
        print('\033[34mBackup realizado com sucesso!!\033[0m')
        return 0
    except IOError as error:
        print('Erro', error)
