from N2.Exercicio1_preencherlista import retornar_lista


def exibe_lista():
    maior = 0
    for nome in retornar_lista():
        if len(nome) > maior:
            maior = len(nome)

    for elementos in retornar_lista():
        if elementos == '':
            continue
        print('{:<{tam_nome}}|_____|_____|_____|_____|_____|_____|_____|'.format(elementos, tam_nome=maior+1))
