lista = []


def preencher_lista(nome):
    lista.append(nome)
    return lista


def retornar_lista():
    lista_ordenada = sorted(lista)
    return lista_ordenada
