from N2.Exercicio1_cabecalho import cabecalho
from N2.Exercicio1_preencherlista import preencher_lista
from N2.Exercicio1_exibirlista import exibe_lista

while True:
    nome = str(input('Nome do aluno? - Fim para finalizar - : ')).title()
    if nome == 'Fim':
        break
    preencher_lista(nome)
exibe_lista()
print(' ')
cabecalho()
