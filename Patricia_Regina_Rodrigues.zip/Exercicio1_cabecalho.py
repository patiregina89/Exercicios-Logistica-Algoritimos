def cabecalho():
    print(40 * '*')
    print('*', 36 * ' ', '*')
    print('*', 'Aluna: Patricia Regina Rogrigues', 3 * ' ', '*')
    print('*', 'Curso: Python Avançado', 13 * ' ', '*')
    print('*', 'Estudante da Faculdade Cesusc', 6 * ' ', '*')
    print('*', 36 * ' ', '*')
    print(40 * '*')
