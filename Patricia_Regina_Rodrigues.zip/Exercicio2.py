lista = [5, 49, 46, 63, 13, 6, 0, 4]


def imprime (nova_lista):
    fim = 8
    quantidade = 1
    while fim > 1 and quantidade <= 4:  # para saber quel é a 4 iteração faz: enquanto fim for maior que 1 e menor ou igual a 4,
        quantidade += 1
        troca = False
        x = 0
        while x < (fim - 1):
            if lista[x] > lista[x + 1]:
                troca = True
                var_temporaria = lista[x]
                lista[x] = lista[x + 1]
                lista[x + 1] = var_temporaria
                print(lista)
            x += 1
        if not troca:
            break
        fim -= 1

    return nova_lista
print(imprime(lista))

# Respostado exercício é a letra D.